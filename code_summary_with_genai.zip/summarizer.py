
from transformers import pipeline

# You can use CodeLlama or other model hosted locally or via Hugging Face
# For simplicity, we're using Hugging Face summarization model here

summarizer = pipeline("summarization", model="Salesforce/codet5-small")

def summarize_code(code):
    try:
        result = summarizer(code[:1024])  # truncating for short summary
        return result[0]['summary_text']
    except Exception as e:
        return f"Error summarizing code: {e}"
