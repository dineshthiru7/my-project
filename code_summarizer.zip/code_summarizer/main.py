"""
Main script to summarize code using a GenAI model like Code LLaMA.
"""
from code_summarizer.summarizer import summarize_code

if __name__ == "__main__":
    file_path = "sample_code/sample.py"  # Replace with the path to your code file
    with open(file_path, 'r') as f:
        code = f.read()
    
    summary = summarize_code(code)
    print("Summary:
", summary)
