
import os
import subprocess
from summarizer import summarize_code
from git import Repo

def clone_repo(repo_url, clone_dir="cloned_repo"):
    if os.path.exists(clone_dir):
        print(f"Directory {clone_dir} already exists. Deleting and recloning.")
        subprocess.run(["rm", "-rf", clone_dir])
    Repo.clone_from(repo_url, clone_dir)
    print(f"Repository cloned to {clone_dir}")
    return clone_dir

def extract_code_files(directory, extensions=[".py", ".js", ".java", ".ts"]):
    code_files = []
    for root, _, files in os.walk(directory):
        for file in files:
            if any(file.endswith(ext) for ext in extensions):
                code_files.append(os.path.join(root, file))
    return code_files

def main():
    repo_url = input("Enter the GitHub repo URL: ")
    repo_dir = clone_repo(repo_url)
    code_files = extract_code_files(repo_dir)
    for file_path in code_files:
        with open(file_path, "r", encoding="utf-8", errors="ignore") as f:
            code = f.read()
            print(f"Summary for {file_path}:")
            print(summarize_code(code))
            print("="*80)

if __name__ == "__main__":
    main()
