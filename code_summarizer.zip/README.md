# Code Summarizer

This project uses GenAI (Code LLaMA) to summarize source code.
